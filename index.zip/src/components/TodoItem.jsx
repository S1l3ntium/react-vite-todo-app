import React from 'react';
import { useDispatch } from 'react-redux';
import { toggleTodo, removeTodo } from '../features/todoSlice.js';
import '../styles/TodoItem.scss';

function TodoItem({ todo }) {
    const dispatch = useDispatch();

    return (
        <li className="todo-item">
            <span
                className={todo.completed ? 'completed' : ''}
                onClick={() => dispatch(toggleTodo(todo.id))}
            >
                {todo.text}
            </span>
            <div>
                <button onClick={() => dispatch(toggleTodo(todo.id))}>
                    {todo.completed ? 'Undo' : 'Complete'}
                </button>
                <button onClick={() => dispatch(removeTodo(todo.id))}>Delete</button>
            </div>
        </li>
    );
}

export default TodoItem;
